#pragma once
#include <raylib.h>

const int screenW = 1600;
const int screenH = 900;
