#pragma once

const int screenW = 1600;
const int screenH = 900;

static bool gameOver;

const int smolAsteroidmax = 5;

void Initialise();
void Update();
void Draw();
